#ifndef TIME_TEST_H
#define TIME_TEST_H

#include "stm32f2xx.h"

void TIM6_NVIC_Configuration(void);
void TIM6_Configuration(void);

#endif	/* TIME_TEST_H */
